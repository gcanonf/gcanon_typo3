-- MariaDB dump 10.19-11.8.5-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	11.8.5-MariaDB-ubu2404-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `config` longtext DEFAULT NULL,
  `icon` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `be_dashboards`
--

DROP TABLE IF EXISTS `be_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_dashboards` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `widgets` text DEFAULT NULL,
  `identifier` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `identifier` (`identifier`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_dashboards`
--

LOCK TABLES `be_dashboards` WRITE;
/*!40000 ALTER TABLE `be_dashboards` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `be_dashboards` VALUES
(1,0,1771673295,1771673295,0,0,0,0,1,'{\"a903607b62047613b26b900b3496d1a1392d0b81\":{\"identifier\":\"t3information\"},\"64c7c08ee57532064a79bb0d05c68edb8cdf0c15\":{\"identifier\":\"docGettingStarted\"}}','ff36b423902613ba28f2db9f51c0dea68a33d251','My dashboard');
/*!40000 ALTER TABLE `be_dashboards` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tables_select` longtext DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pagetypes_select` longtext DEFAULT NULL,
  `tables_modify` longtext DEFAULT NULL,
  `non_exclude_fields` longtext DEFAULT NULL,
  `explicit_allowdeny` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `custom_options` longtext DEFAULT NULL,
  `groupMods` longtext DEFAULT NULL,
  `mfa_providers` longtext DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `subgroup` varchar(255) DEFAULT '',
  `category_perms` longtext DEFAULT NULL,
  `availableWidgets` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `be_sessions`
--

DROP TABLE IF EXISTS `be_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` longblob DEFAULT NULL,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_sessions`
--

LOCK TABLES `be_sessions` WRITE;
/*!40000 ALTER TABLE `be_sessions` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `be_sessions` VALUES
('f2e9d2552456304e2c2480dbd40265479fb2b78d637149f3a193abf7df21466e','[DISABLED]',1,1771764507,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"70303c878e03942ee30bd0bb24fb700ddd4e3748f2c1ea2dc306504e31d47087\";}');
/*!40000 ALTER TABLE `be_sessions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `lang` varchar(10) NOT NULL DEFAULT 'default',
  `uc` mediumblob DEFAULT NULL,
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `password_reset_token` varchar(100) NOT NULL DEFAULT '',
  `username` varchar(50) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `realName` varchar(80) NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `options` smallint(5) unsigned NOT NULL DEFAULT 3,
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 1,
  `userMods` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `TSconfig` longtext DEFAULT NULL,
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `category_perms` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

LOCK TABLES `be_users` WRITE;
/*!40000 ALTER TABLE `be_users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `be_users` VALUES
(1,0,1771673264,1771673264,0,0,0,0,NULL,'default','a:7:{s:10:\"moduleData\";a:4:{s:28:\"dashboard/current_dashboard/\";s:40:\"ff36b423902613ba28f2db9f51c0dea68a33d251\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";a:0:{}s:10:\"FormEngine\";a:2:{i:0;a:2:{s:32:\"696addfecc296b326ff6e9f04c7ff3e1\";a:5:{i:0;s:4:\"Home\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:28:\"&edit%5Bpages%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:1;s:3:\"pid\";i:0;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:76:\"/typo3/module/web/layout?token=58fe10d32628300be336797b7de662bfb87eba15&id=0\";}s:32:\"9b967901d6c9df7fbe10e9cd1eacc0fe\";a:5:{i:0;s:4:\"Home\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";a:1:{s:5:\"pages\";a:1:{s:16:\"sys_language_uid\";s:1:\"0\";}}s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:76:\"&edit%5Bpages%5D%5B1%5D=edit&overrideVals%5Bpages%5D%5Bsys_language_uid%5D=0\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:1;s:3:\"pid\";i:0;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:76:\"/typo3/module/web/layout?token=58fe10d32628300be336797b7de662bfb87eba15&id=1\";}}i:1;s:32:\"9b967901d6c9df7fbe10e9cd1eacc0fe\";}s:10:\"system_log\";a:1:{s:10:\"constraint\";s:337:\"O:39:\"TYPO3\\CMS\\Belog\\Domain\\Model\\Constraint\":11:{s:14:\"\0*\0userOrGroup\";s:1:\"0\";s:9:\"\0*\0number\";i:20;s:15:\"\0*\0workspaceUid\";i:-99;s:10:\"\0*\0channel\";s:3:\"php\";s:8:\"\0*\0level\";s:5:\"debug\";s:17:\"\0*\0startTimestamp\";i:0;s:15:\"\0*\0endTimestamp\";i:0;s:18:\"\0*\0manualDateStart\";N;s:17:\"\0*\0manualDateStop\";N;s:9:\"\0*\0pageId\";i:0;s:8:\"\0*\0depth\";i:0;}\";}}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:20:\"edit_docModuleUpload\";s:1:\"1\";s:15:\"moduleSessionID\";a:4:{s:28:\"dashboard/current_dashboard/\";s:40:\"37cedb2fb9cf88a2e2727d6faa41304a7bb1ad7b\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";s:40:\"c3851c526891e580ed25557e16dc61f2b8306000\";s:10:\"FormEngine\";s:40:\"37cedb2fb9cf88a2e2727d6faa41304a7bb1ad7b\";s:10:\"system_log\";s:40:\"c3851c526891e580ed25557e16dc61f2b8306000\";}s:10:\"modulemenu\";s:2:\"{}\";s:17:\"systeminformation\";s:40:\"{\"system_log\":{\"lastAccess\":1771753723}}\";}',0,NULL,'','gcanon','$argon2i$v=19$m=65536,t=16,p=1$Z1d0ZTFvTC9KUFoxaWduUw$NWmpA1qkpgc+AwxVYxnj0d+O8WFOAHU/uUxAWQDJ8UQ','',0,NULL,'','gustavo@gcanon.de','',1,3,NULL,1,NULL,'',NULL,1771752608,NULL);
/*!40000 ALTER TABLE `be_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `cache_hash`
--

DROP TABLE IF EXISTS `cache_hash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash`
--

LOCK TABLES `cache_hash` WRITE;
/*!40000 ALTER TABLE `cache_hash` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `cache_hash` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `cache_hash_tags`
--

DROP TABLE IF EXISTS `cache_hash_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash_tags`
--

LOCK TABLES `cache_hash_tags` WRITE;
/*!40000 ALTER TABLE `cache_hash_tags` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `cache_hash_tags` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `cache_pages`
--

DROP TABLE IF EXISTS `cache_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages`
--

LOCK TABLES `cache_pages` WRITE;
/*!40000 ALTER TABLE `cache_pages` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `cache_pages` VALUES
(1,'1_df373b81c36c269c',1771840141,'x��\Zks۸���W l?���%K�\\�4�������i:�\\J�I�%()�L�{�HS�,?�v��I��}`w҉eN��I0�*:�+�j\'lb�����\r���O�e�m����g�?CM�����䴜�4(��.494=�Lh(I��̴e��!B��/t��~xE����Y\0A��:��hjZ�s�\\�@$ސWP~�+�ϼi����JLc�^��A�Z�q�c4��r�YC,X�V|\r5�Cz-+��RT�f�T��HÉ@a��+ģ$���$�/��Y��Ȱ��Z�ּ�F��a4�7$��6-ǟ���&ה����2%9K��\nX�)ν��7�����u«M�拆XQ�i��g�����G0^��5�U�jR�$\r[�B�%�ټ+3^�A<%�4v��e;��Zn6wƼ�#]���Yy���G#�\Z��f\\Q�VFa\Zy���V�i@]˱l?��4}�b!]I�1~iy\0�+P�ƪL�Kj.x֌t��59���@��Z�rj����ͤ�:�k�V3틾�::B�ˋs��֓gڻ73H�uX%�m���B^ [3�}�؃]1XW�n�k�6�Y\n�\"�����t��f�K�̊e�\r�Q�y��<���+���x���l�c�##�uZUzB+��Ȓ﯏���L)rtPmצ��� \0MoY�\r��5qtۘ32�+;tc\Z%��z4���	��I�8l\0�\'�B�[�I�8	�������(HM/cW$)�!�b�x��\Z) et�aT�u=NV���hF�R��<�zr�\"%pL�΢R�t��Ʈd�k\'��dV\ZǱ�+2cߊv��[�(�A���Yh&N�D�a�DI%4��Ц^����ڨ����4��I���~R�`b蕝�]�a��@��=���!�h���4�醰t�UzW�k��<�[D�䰂\\7U�X�a���2P�9��e����eސ�G�)[)�\r��ө�������d��s	+s�\\T��c&�_3���Lb۔$*Z��6rL�h���<�����k���<\0�����=)�$�p�*�R�P#�7 K!�s9\'�ʧ@�B�c��+���xʌ��e�Y�C�Ш\\�h*j%&DL�;\n�J�2Q0qT�oyCX����M���Q|��S(7ǘ����J^F�1���%)x�dr8��t��>F1��%�6$I]�h3,tK����LV7Gd�j���\\Ê_����,\Z,t�g5O�}\nx���:_b��9��*@��a���==\Z��\r�mV�3��&�ϔv�f��RV���a,��\'K!M�r�.�Y��A���?��%ַ�V��=�~1��$wW	Jn`��V�=}6��p���+��?/Q�դ��#I8���-ύe}��%mm\"�t鶫d��KĴ��w�׍v���qA��:�n@*����F$�<����1���h\\��l��2ŞI6?3�Æ\\ȴ���BS۳����C���Ϲ^�v�@Q\'�j�8$�b5�͛Cb�lIg�gk��4+�����p�Ĭ\\A�-����y>�G�\'G�����5Z���u�O��S��w�����q��#&{>%[T/{��Ǐg?]ŸM������1��-)���6\\�!�X�wL��u�2m��f���`��v��P�-�i\'��\nZ\\���ގx0v�꼭!�V-����Jx�,����Y=�l���=��������Gz=R��c�[��.�4�\'1w�P&���ek<��@Jq/.�QLw	�A���q�IFr����t����p0[�?�s����� �S;�����%�ڦ�r�o����wqO��D�f�3���������;�=�>��e+x E~�#����A�~�&��^jw��$ם.s��;\"W2�\n�?<T�{�G/R�:x�^tܗv�i_6�?����~S�s&�,��[�����-�w9*���٭�k���Q]���z��L�ӏ˲�vk�,n�&�����mڍ�sy�x�9��T����@u-{>./�drQu�4���!{���1<n�lJ~�Q��A�(x\"�9��O�ax���n�Y��s<��?�?2�n������C>�Z�S���c�P�u��v7�4݉�������4J$5�su����5$O����Dop�mo�����lTҞ�m�0D`U�=�yȥ�P7���L��tB��<�K�ȁ$�н�73<��7���Q+u�$	h���;w�R@%�dqM�Xib�Y�v���B{�Ec/sS=t�0�2ߦv�~�fN�;A��1Y���ŧ:H����ws,�U�Rޅ���N��4\n��}G����/��L.e�N���o8���\\!���۾\'t)}��&�s�|��\r\'�;��>\\|:��鼃��^���y�WLǢ(HQ�֡� y�I��z	��@�ʷ�,g��r�5m�E#_[��:�t�s�l>�SC��L�\\,�I��׵�.�Z&�?��8E�2)�%�Iʟ|e�J\\Y݋P�9��F\\e,�vԖ��`TJ&o�igɖ��Hj�����.�t�)Y�54�N�kZ��o��)p�');
/*!40000 ALTER TABLE `cache_pages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `cache_pages_tags`
--

DROP TABLE IF EXISTS `cache_pages_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages_tags`
--

LOCK TABLES `cache_pages_tags` WRITE;
/*!40000 ALTER TABLE `cache_pages_tags` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `cache_pages_tags` VALUES
(1,'1_df373b81c36c269c','pages_1'),
(2,'1_df373b81c36c269c','sys_file_1'),
(3,'1_df373b81c36c269c','sys_file_metadata_1'),
(4,'1_df373b81c36c269c','sys_file_2'),
(5,'1_df373b81c36c269c','sys_file_metadata_2'),
(6,'1_df373b81c36c269c','pageId_1');
/*!40000 ALTER TABLE `cache_pages_tags` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `cache_rootline`
--

DROP TABLE IF EXISTS `cache_rootline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline`
--

LOCK TABLES `cache_rootline` WRITE;
/*!40000 ALTER TABLE `cache_rootline` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `cache_rootline` VALUES
(1,'1__0_0_1_1',1774345723,'x�uT�n�0�}@+��#�)h��P����A�+�0E�|�6��{��%Qvrg�}�̊���K�?0�ْwG�$Rd�ݩ�O9��$�γ��M��,7���p+��$����\r�(�f�����d��z/0|Z�Ȗd%�ʚ���I�����^�*�[�ֈw$����[�zit�\0Ӏ�^~2ؑ;;������i� �*rM[fA�ؙ`��c���x���	Y��u�����l�#���7��$�xt�z�R������q48������x��DtY\\�\'�;�7�{��yo�ȳ������{�������Ӎ{PW��<�Tn�G�iiMC�搥��\r���ʦ�SK��U*bXzhXK[+1��Y�����b#a���@\r���&�V�g��N��S�d�/�z�a����u��-�\0�0mJ-G�*l\\��T�l��	)�f�-\n�4{�c���#��J�ƅ��Ÿ��V�,��U�����?m\\m�d�p���Tc��8��ƕMg��\0��i�\0�:`��i���1�p>\Z+�U{�%g{�-�~>3�9H�2��ூ]U��F/Yc��F�đԌ��#,µB��j��jM�g��B������:H5��*ܴ�Vq\\oC*5WA��̧�1x_�)����Q�����\Z��PZ�����:k�%g�*��\"��)� ����M��-�?J��ߦ��b��L_�d^L1ά��)�g�b�:4{�����?��FN'),
(2,'1__0_0_0_0',1774345741,'x�uT�n�0�}@+��#�)h��P����A�+�0E�|�6��{��%Qvrg�}�̊���K�?0�ْwG�$Rd�ݩ�O9��$�γ��M��,7���p+��$����\r�(�f�����d��z/0|Z�Ȗd%�ʚ���I�����^�*�[�ֈw$����[�zit�\0Ӏ�^~2ؑ;;������i� �*rM[fA�ؙ`��c���x���	Y��u�����l�#���7��$�xt�z�R������q48������x��DtY\\�\'�;�7�{��yo�ȳ������{�������Ӎ{PW��<�Tn�G�iiMC�搥��\r���ʦ�SK��U*bXzhXK[+1��Y�����b#a���@\r���&�V�g��N��S�d�/�z�a����u��-�\0�0mJ-G�*l\\��T�l��	)�f�-\n�4{�c���#��J�ƅ��Ÿ��V�,��U�����?m\\m�d�p���Tc��8��ƕMg��\0��i�\0�:`��i���1�p>\Z+�U{�%g{�-�~>3�9H�2��ூ]U��F/Yc��F�đԌ��#,µB��j��jM�g��B������:H5��*ܴ�Vq\\oC*5WA��̧�1x_�)����Q�����\Z��PZ�����:k�%g�*��\"��)� ����M��-�?J��ߦ��b��L_�d^L1ά��)�g�b�:4{�����?��FN');
/*!40000 ALTER TABLE `cache_rootline` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `cache_rootline_tags`
--

DROP TABLE IF EXISTS `cache_rootline_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline_tags`
--

LOCK TABLES `cache_rootline_tags` WRITE;
/*!40000 ALTER TABLE `cache_rootline_tags` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `cache_rootline_tags` VALUES
(1,'1__0_0_1_1','pageId_1'),
(2,'1__0_0_0_0','pageId_1');
/*!40000 ALTER TABLE `cache_rootline_tags` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `subgroup` varchar(255) DEFAULT '',
  `felogin_redirectPid` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `fe_sessions`
--

DROP TABLE IF EXISTS `fe_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` mediumblob DEFAULT NULL,
  `ses_permanent` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`,`ses_userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_sessions`
--

LOCK TABLES `fe_sessions` WRITE;
/*!40000 ALTER TABLE `fe_sessions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `fe_sessions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `uc` blob DEFAULT NULL,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `felogin_forgotHash` varchar(80) DEFAULT '',
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `name` varchar(160) NOT NULL DEFAULT '',
  `first_name` varchar(50) NOT NULL DEFAULT '',
  `middle_name` varchar(50) NOT NULL DEFAULT '',
  `last_name` varchar(50) NOT NULL DEFAULT '',
  `address` longtext DEFAULT NULL,
  `telephone` varchar(30) NOT NULL DEFAULT '',
  `fax` varchar(30) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(40) NOT NULL DEFAULT '',
  `zip` varchar(10) NOT NULL DEFAULT '',
  `city` varchar(50) NOT NULL DEFAULT '',
  `country` varchar(40) NOT NULL DEFAULT '',
  `www` varchar(80) NOT NULL DEFAULT '',
  `company` varchar(80) NOT NULL DEFAULT '',
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `felogin_redirectPid` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`),
  KEY `felogin_forgotHash` (`felogin_forgotHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `doktype` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `slug` text DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `php_tree_stop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `nav_hide` smallint(5) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) NOT NULL DEFAULT '',
  `target` varchar(80) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `lastUpdated` bigint(20) NOT NULL DEFAULT 0,
  `newUntil` bigint(20) NOT NULL DEFAULT 0,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) NOT NULL DEFAULT '',
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `keywords` longtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `abstract` longtext DEFAULT NULL,
  `author` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `is_siteroot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `module` varchar(255) NOT NULL DEFAULT '',
  `l18n_cfg` smallint(5) unsigned NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) NOT NULL DEFAULT '',
  `tsconfig_includes` varchar(255) DEFAULT '',
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `no_index` smallint(5) unsigned NOT NULL DEFAULT 0,
  `no_follow` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sitemap_changefreq` varchar(10) NOT NULL DEFAULT '',
  `canonical_link` text NOT NULL DEFAULT '',
  `og_title` varchar(255) NOT NULL DEFAULT '',
  `og_description` longtext DEFAULT NULL,
  `og_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_title` varchar(255) NOT NULL DEFAULT '',
  `twitter_description` longtext DEFAULT NULL,
  `twitter_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_card` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `slug` (`slug`(127)),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `pages` VALUES
(1,0,1771673703,1771673593,0,0,0,0,'',256,'',0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,0,31,27,0,1771673703,0,0,0,0,0.5,1,'Home','/','',0,0,0,0,'',0,'','','',0,0,0,'',0,0,'','','','','',0,1,0,'',0,'','','','',0,0,'','','','',0,'','',0,'');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `route` varchar(255) NOT NULL DEFAULT '',
  `arguments` text DEFAULT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `items` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid_local`,`uid_foreign`,`tablenames`,`fieldname`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `sys_csp_resolution`
--

DROP TABLE IF EXISTS `sys_csp_resolution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_csp_resolution` (
  `summary` varchar(40) NOT NULL,
  `created` int(10) unsigned NOT NULL,
  `scope` varchar(264) NOT NULL,
  `mutation_identifier` text DEFAULT NULL,
  `mutation_collection` mediumtext DEFAULT NULL,
  `meta` mediumtext DEFAULT NULL,
  PRIMARY KEY (`summary`),
  KEY `created` (`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_csp_resolution`
--

LOCK TABLES `sys_csp_resolution` WRITE;
/*!40000 ALTER TABLE `sys_csp_resolution` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sys_csp_resolution` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `identifier` text DEFAULT NULL,
  `identifier_hash` varchar(40) NOT NULL DEFAULT '',
  `folder_hash` varchar(40) NOT NULL DEFAULT '',
  `extension` varchar(255) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `sha1` varchar(40) NOT NULL DEFAULT '',
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  `size` bigint(20) NOT NULL DEFAULT 0,
  `storage` int(10) unsigned NOT NULL DEFAULT 0,
  `type` int(10) unsigned NOT NULL DEFAULT 0,
  `mime_type` varchar(255) NOT NULL DEFAULT '',
  `missing` smallint(5) unsigned NOT NULL DEFAULT 0,
  `metadata` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sys_file` VALUES
(1,0,1771753684,1771753684,'/_assets/fe8d87e9591d21cbdd7a4131269e9006/Images/logo.svg','e324eaa0ba610f0639b8a1c8d2e350a652969e6c','35e7228f3108bd54cedb4d69436c71462b5afd0d','svg','logo.svg','f97b55ab95885df9797440f4f4b74b0a4911e120',1771753311,1771753311,2566,0,2,'image/svg+xml',0,0),
(2,0,1771753684,1771753684,'/_assets/fe8d87e9591d21cbdd7a4131269e9006/Images/logo-inverted.svg','586cb9f09a2af7caa9fa485ae9e94510b859bf15','35e7228f3108bd54cedb4d69436c71462b5afd0d','svg','logo-inverted.svg','6f9c74943d9b212d9e04c6cbe4ef3dd8a91f271e',1771753311,1771753311,2578,0,2,'image/svg+xml',0,0);
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `type` varchar(30) NOT NULL DEFAULT 'static',
  `files` int(10) unsigned NOT NULL DEFAULT 0,
  `folder_identifier` longtext DEFAULT NULL,
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `file` int(10) unsigned NOT NULL DEFAULT 0,
  `description` longtext DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `fal_filelist` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sys_file_metadata` VALUES
(1,0,1771753684,1771753684,0,0,NULL,'',0,0,0,0,NULL,NULL,0,1,NULL,185,50),
(2,0,1771753684,1771753684,0,0,NULL,'',0,0,0,0,NULL,NULL,0,2,NULL,185,50);
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `processing_url` text DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) NOT NULL DEFAULT '',
  `task_type` varchar(200) NOT NULL DEFAULT '',
  `checksum` varchar(32) NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sys_file_processedfile` VALUES
(1,1771753684,1771753684,0,1,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','f97b55ab95885df9797440f4f4b74b0a4911e120','Image.CropScaleMask','63324cc1b8',185,50),
(2,1771753684,1771753684,0,2,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','6f9c74943d9b212d9e04c6cbe4ef3dd8a91f271e','Image.CropScaleMask','425ab171f0',185,50);
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `link` text NOT NULL DEFAULT '',
  `description` longtext DEFAULT NULL,
  `crop` longtext DEFAULT NULL,
  `autoplay` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `processingfolder` tinytext DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `is_browsable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_default` smallint(5) unsigned NOT NULL DEFAULT 0,
  `is_writable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_online` smallint(5) unsigned NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(5) unsigned NOT NULL DEFAULT 1,
  `driver` varchar(255) NOT NULL DEFAULT '',
  `configuration` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sys_file_storage` VALUES
(1,0,1771673556,1771673556,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.',1,NULL,'fileadmin',1,1,1,1,1,'Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>');
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `identifier` longtext DEFAULT NULL,
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `history_data` mediumtext DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  `correlation_id` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--

LOCK TABLES `sys_history` WRITE;
/*!40000 ALTER TABLE `sys_history` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sys_history` VALUES
(1,1771673593,1,'BE',1,0,1,'pages','{\"doktype\":\"1\",\"slug\":\"\\/\",\"categories\":\"0\",\"layout\":\"0\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":\"1\",\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":0,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Home\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"0\",\"no_follow\":\"0\",\"sitemap_changefreq\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"target\":\"\",\"cache_tags\":\"\",\"is_siteroot\":\"0\",\"no_search\":\"0\",\"php_tree_stop\":\"0\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"0\",\"nav_hide\":\"0\",\"extendToSubpages\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1771673593,\"t3ver_stage\":0,\"tstamp\":1771673593,\"uid\":1}',0,'0400$659d25b80678968e0b5cd926a55d5dfe:e175f7045d7ccbfb26ffcf279422c2e5'),
(2,1771673593,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"slug\\\":\\\"\\\"}\"}}',0,'0400$67f16cdfa07d05034b7be9eb16525047:e175f7045d7ccbfb26ffcf279422c2e5'),
(3,1771673618,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"is_siteroot\":0,\"l10n_diffsource\":\"{\\\"slug\\\":\\\"\\\"}\"},\"newRecord\":{\"is_siteroot\":\"1\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\"}\"}}',0,'0400$8c8ab0fca43fc0cf5e0328db3404c9a8:e175f7045d7ccbfb26ffcf279422c2e5'),
(4,1771673703,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$02a2c78e2378798c6e13cf1c3e297d36:e175f7045d7ccbfb26ffcf279422c2e5');
/*!40000 ALTER TABLE `sys_history` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `sys_http_report`
--

DROP TABLE IF EXISTS `sys_http_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_http_report` (
  `uuid` varchar(36) NOT NULL,
  `status` smallint(5) unsigned NOT NULL DEFAULT 0,
  `created` int(10) unsigned NOT NULL,
  `changed` int(10) unsigned NOT NULL,
  `type` varchar(32) NOT NULL,
  `scope` varchar(100) NOT NULL,
  `request_time` bigint(20) unsigned NOT NULL,
  `meta` mediumtext DEFAULT NULL,
  `details` mediumtext DEFAULT NULL,
  `summary` varchar(40) NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `type_scope` (`type`,`scope`),
  KEY `created` (`created`),
  KEY `changed` (`changed`),
  KEY `request_time` (`request_time`),
  KEY `summary_created` (`summary`,`created`),
  KEY `all_conditions` (`type`,`status`,`scope`,`summary`,`request_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_http_report`
--

LOCK TABLES `sys_http_report` WRITE;
/*!40000 ALTER TABLE `sys_http_report` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sys_http_report` VALUES
('0360f23e-408d-4414-b82f-004a7e6da35e',0,1771673512,1771673512,'csp-report','backend',1771673512559721,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/web\\/layout?id=0\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/web\\/layout?id=0\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-gvDBC3DKELdagmzR4nm2kEdrqCObL86f9SscBLGVniiBJf1T1ceY1w\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771673512559721&requestHash=ea6893dd348ff0eff0a2e29fbbf72a71b99d346a\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('0add86cf-eaae-4fb6-b1d1-6699f7787b05',0,1771673557,1771673557,'csp-report','backend',1771673556671566,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/record\\/edit?edit%5Bpages%5D%5B0%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D58fe10d32628300be336797b7de662bfb87eba15%26id%3D0\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/web\\/layout?id=0\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce--5D61tkXt_trq7Oi9em9mtkoD5ijmybqFO1gkx0qZjRfoubu5jCEPA\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771673556671566&requestHash=5fbb8f817a991e0986a90dfabbfc30337f298f5d\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('0e45de37-b2fa-475a-96d5-b55c151f29b6',0,1771673713,1771673713,'csp-report','backend',1771673713107116,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/web\\/layout?id=1\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-eoHads5avXPXXrd_i8e-oIWZbhQQGVwYDB9Sh9I2WA4Hx5ODZlnpwA\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771673713107116&requestHash=6e4c08e6e2b127e212c954a2b16b6e8c47c1546f\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('13f54a0a-44aa-4926-a5d3-c1a301ed76ef',0,1771673424,1771673424,'csp-report','backend',1771673423945429,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/web\\/layout\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-ODnoCfbb807LHiO2vRE27Ar9_3YA27hYkmlUG79Z4M_wG_DmPaTfyw\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771673423945429&requestHash=c4f1e0701cb52282c2903390c5a42d222d336402\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('15bf36fb-2b14-47b7-8d9f-45f416569842',0,1771673594,1771673594,'csp-report','backend',1771673593892483,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/record\\/edit?edit%5Bpages%5D%5B1%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D58fe10d32628300be336797b7de662bfb87eba15%26id%3D0\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/record\\/edit?edit%5Bpages%5D%5B0%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D58fe10d32628300be336797b7de662bfb87eba15%26id%3D0\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-7lwYJjDr3jMYt_Vllympq8Mv8veMfZzbr7ls4gaYrAXT0JG-88Hrhg\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771673593892483&requestHash=d24fbb8f24dd7ca4eeccee79d86dbf476ed42671\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('17871845-f3b6-473b-bf73-4674ef091d71',0,1771674147,1771674147,'csp-report','backend',1771674146890006,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/record\\/edit?edit%5Bpages%5D%5B1%5D=edit&overrideVals%5Bpages%5D%5Bsys_language_uid%5D=0&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D58fe10d32628300be336797b7de662bfb87eba15%26id%3D1\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/web\\/layout?id=1\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-CgEix8vCueNWV_-JERN-6zt3MO8HIQ40OpTuRsAO9b_ebhtT2tYYHQ\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771674146890006&requestHash=463c3f3c8fd403895c1aa9e1ff28c21e238db215\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('1b92b440-a4b0-4d63-bf7b-df089b3d9095',0,1771764507,1771764507,'csp-report','backend',1771764507007515,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/system\\/log\\/BackendLog\\/list\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/main?redirect=system_log.BackendLog_list&referrer-refresh=1771764511\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-jllbUIPBtZsxJdoxrk-eEj1t93EvykbIZ8TQ9HVqaeEsLD0Ri6jNLg\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771764507007515&requestHash=5b006f261cd6a423fd0ec4f0c0d2cf1870311ec8\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('1d5f600c-157d-4570-92c5-555e4e15bc4c',0,1771753738,1771753738,'csp-report','backend',1771753737582051,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/system\\/log\\/BackendLog\\/list\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/main?redirect=system_log.BackendLog_list\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-NZAio3eqahcvQGoImY4c6W2GPgmDBeq7gQ4EEtgzyEwK8bJhOhfq7w\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771753737582051&requestHash=f4d947ab44b419c7173123f1c7d471c967a6b975\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('2fde13e5-5979-44ff-bfa8-ef7d3328fef4',0,1771673736,1771673736,'csp-report','backend',1771673736618444,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\\/edit?site=autogenerated-1-c4ca4238a0b923820dcc509a6f75849b\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-iaSnXsoTbsEl2iXAqjE8O1Q5rbBnznoYkPHzjVwwCe2ProKiUhRGhA\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771673736618444&requestHash=0a2ae019ce5b6d2a499caac47d9694c7bc687a37\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('365f8f7f-eb79-4f18-8c61-080ffdb084e8',0,1771752837,1771752837,'csp-report','backend',1771752837017665,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/dashboard\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-8pLDR7C9ch8z3vvJ7f9yNhwUNjUP1CoaHoc_Dg8KyUlX64CUpuuPzg\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771752837017665&requestHash=07b39eac3399bb4eec93d825b747a903d1b4df6b\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('3ec33ccb-09eb-4a1b-aee9-9cbe2ded38fc',0,1771753489,1771753489,'csp-report','backend',1771753489003019,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/settings\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/main?redirect=site_settings\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-H5kubz5pjmkjiJdIFGY5U7ThvL3E7kiJzBQ95dwz3Lyis9CafU-oyg\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771753489003019&requestHash=6f3906db0a6718676efb8337866b9867faf25e20\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('46c1cd94-78f2-46ad-9571-a9beec1cf768',0,1771680051,1771680051,'csp-report','backend',1771680051857572,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/dashboard\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/main?redirect=dashboard\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-w7FJhhnKwi0Y62XUvOIXCS1gPQBi05nNBBUv1VoiPwYhAnNlD-bWGQ\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771680051857572&requestHash=3d6c29b3a1e3f1e96db5145297ebcd27b63f727d\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('4935f376-7716-49ea-a8d2-f5fbbc0068f8',0,1771752943,1771752943,'csp-report','backend',1771752943599226,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/settings\\/edit?site=gcanon\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/settings\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-2D4dEGlqsu5PXeN6YY8M8Iit0lQqzdwGQfGtIgjmGKfATAL1XvQGOw\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771752943599226&requestHash=163c1e3299d4ff263efd976d72d110dffef9f92e\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('4f090963-a583-45a0-8c5b-d32c43f67f80',0,1771680051,1771680051,'csp-report','backend',1771680051693160,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"about\",\"referrer\":\"\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-U_-EhciyyLdjyXIdVTU8T310mjijkCOBEna-eqxEoju5202o21D94g\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771680051693160&requestHash=ecc90cf7335edfcef263a97c171092987f29743e\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":0,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('504e2fe8-e237-4092-9d5a-212ed8418411',0,1771691117,1771691117,'csp-report','backend',1771691116955814,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/web\\/layout?id=1\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/main?redirect=web_layout&redirectParams=id%3D1&referrer-refresh=1771691121\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-z7dvxBsv1jtScLJybvhSoEZCoTYlhfK925itU7a0hJmrb5xYNltFCQ\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771691116955814&requestHash=38157346320eb82b16456c5a0be75717dfef96a3\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('5074c658-c9db-4199-9ee5-512563e202b1',0,1771674107,1771674107,'csp-report','backend',1771674106717807,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/tools\\/extensionmanager\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/main?redirect=extensionmanager\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-75d1KsV1QqSKwUHHI-hThdzEZFli02gVdfgV5c9befhsx_O6aemYUQ\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771674106717807&requestHash=dd76e252751c67df39a51829617622c06c13aa04\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('5d06ed10-eb2b-40f1-99a5-df93b1c3d4aa',0,1771753732,1771753732,'csp-report','backend',1771753732104765,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/system\\/log\\/BackendLog\\/list\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/system\\/log?constraint%5Bchannel%5D=php\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-Zh64O5tP8tzYQKEZ9tddruEVPpzFe0WcgIv0JNW4KcxMf_FAT4B5IQ\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771753732104765&requestHash=9f81cb4293d72e9c2115b3a69557a9551bd34e8d\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('6362157e-fc16-4d14-92ff-c23bce5f8097',0,1771673456,1771673456,'csp-report','backend',1771673456794201,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/web\\/layout\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-5a6SG6lvEepphz3YaS1C52l-iWMlC7k1taCSjQWC2TSRGEa9-1APtg\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771673456794201&requestHash=d0db84a2a923ecb8451b9c79eb05b2feea329392\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('6510387b-28a4-4e38-bb93-d3dced331711',0,1771676975,1771676975,'csp-report','backend',1771676974827460,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/dashboard\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/main\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-s0RB8nKhMlFp12kAUg8WiJnEN2Gb-gz9aWOWeq3wccuaCr1EFA89UQ\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771676974827460&requestHash=90dc8bda10cf0469aa26d40c21434860232e9671\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('672a29e7-6460-40a3-a892-528e38de6df6',0,1771673761,1771673761,'csp-report','backend',1771673761761054,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\\/edit?site=autogenerated-1-c4ca4238a0b923820dcc509a6f75849b\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-KuE-UsBfNSusbC48gOAC2gQxKqkBWfEEQE_rf40O64bElkxzeb_tpA\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771673761761054&requestHash=7bb5ff6cbe2caedc2d7c024051ec5f401a947cec\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('704ef2d4-55ee-458c-9029-c924fafa5e31',0,1771753492,1771753492,'csp-report','backend',1771753492509354,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\\/edit?site=gcanon\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-xWyiXAA_5cUHoTOmRVXLSSna0yn1RisOfVSuz5Ffv8V84987uDmTrA\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771753492509354&requestHash=08052f869c0de858d21b12af763ecd062ac6002e\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('76fa3a6d-b8d1-4ae5-87ad-4dfaaf0ff3b2',0,1771752941,1771752941,'csp-report','backend',1771752941548635,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/settings\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\\/edit?site=gcanon\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-09W05pgeZOuljO8TDEZ1DO--Jg73JQlcWoVorCGXso718jiXuEUgeA\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771752941548635&requestHash=e46e9bacb34bf17ce6fb41095362d6fade8af559\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('7f75334c-a36b-4672-b890-781823e681e8',0,1771673792,1771673792,'csp-report','backend',1771673792796246,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\\/edit?site=gcanon\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\\/edit?site=autogenerated-1-c4ca4238a0b923820dcc509a6f75849b\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-6wRIJwnudS2CS9pkvRg8Zwqd9KBGFg4_FO5JMnmhF7gsZ8Tz8l5Vmg\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771673792796246&requestHash=044aa76dd1797c8e6d5b725bf8549e8c2cefb7c9\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('8001bf4b-134d-4f27-a228-f21511d8f432',0,1771753723,1771753723,'csp-report','backend',1771753723613022,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/system\\/log?constraint%5Bchannel%5D=php\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\\/edit?site=gcanon\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-S02bAQ4nwAUx794Ym1K2bQa5OFPvjOSRSqm72cmla9VbjXjkOnDKwQ\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771753723613022&requestHash=ea663404f19b32eec02e0817c53017c2b5884496\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('84821c3d-31a1-4632-8b4b-bb7465fed6dc',0,1771674142,1771674142,'csp-report','backend',1771674142053751,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/web\\/layout?id=1\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/web\\/layout?id=1\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-4EIQePfgksyR8BWIdcRg_IJH5T7_nJmu4vpzR8zSn9rF-H-cLy0qGA\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771674142053751&requestHash=34fec4c2b70a7908bae0c1d31bcb95e068c273fa\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('85949a02-7a50-4a08-b0d4-b9d59e96623d',0,1771674041,1771674041,'csp-report','backend',1771674041191632,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/sudo-mode\\/module?claim=b57bc3602f9322e7215e1966218e305e04062945&hash=eefb531d53d0ddb52b6b86ae350ce0414d8fe89b\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\\/edit?site=gcanon\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-vCj5-Vx7QIQyyBuzIF_mSAC71Etv-kx4sEyTAHjYGvCmjJ3guu8U6g\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771674041191632&requestHash=8702b6993eebc0b44c22e3345194e5d4df153b4f\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('8c36fe64-6a6f-474a-ae37-17d427485cf1',0,1771674289,1771674289,'csp-report','backend',1771674288811397,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"about\",\"referrer\":\"\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-0Edp7ustdlVuIf4gTc8za-wD2BSLNBYW1zzwtsP1xK-9Yz-IJr6Pew\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771674288811397&requestHash=f3ac439dd0f47867fcfde70a7fabbc482db2844f\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":0,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('8f678179-5949-4914-8b46-f3037a1b292f',0,1771752835,1771752835,'csp-report','backend',1771752834941453,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"about\",\"referrer\":\"\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-GZxjiUjS9XNdDjiPEkeWaOMg-miUhV4yF4R0W2BQBnA_tQr_tN3V5Q\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771752834941453&requestHash=3e2fb901d587e81f316f23516788cb50fb618096\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":0,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('91bcd892-5423-49c5-922d-c945a8debc3e',0,1771673610,1771673610,'csp-report','backend',1771673609915748,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/record\\/edit?edit%5Bpages%5D%5B1%5D=edit&overrideVals%5Bpages%5D%5Bsys_language_uid%5D=0&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D58fe10d32628300be336797b7de662bfb87eba15%26id%3D1\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/web\\/layout?id=1\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-OiBbVupg_EClTCSig-0xRQBF6MYWWfvSXlZ4Rn-R2llOSOm4w_MyhA\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771673609915748&requestHash=892ab448fc99e7db8198443848cfe029e24f6acd\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('92627dba-6364-4ad4-ba41-5f9a9a9bdd40',0,1771674289,1771674289,'csp-report','backend',1771674289042312,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/dashboard\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/main?referrer-refresh=1771674293\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-K_ri1N2qqM0GlyRvJj7twZV0_bpeIXJsqGv6pWtqcVaPn4FBBEh46A\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771674289042312&requestHash=76039b53723b5b7e78b1296da2fcf8676d3841c3\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('92dd48c2-8854-48d1-8fb2-dce002587326',0,1771674141,1771674141,'csp-report','backend',1771674141344302,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/web\\/layout?id=1\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/web\\/layout?id=1\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-ItTX44Pebo3m1fN7ZVbkzBtWIErWClNzsPwsI4flvbaX0JZZzQkttQ\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771674141344302&requestHash=b0662b9e5b519c5196d9ebc9ffef2a00574a7280\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('9856a6a9-f9aa-4224-8950-73f103595bf5',0,1771673728,1771673728,'csp-report','backend',1771673728031685,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\\/edit?site=autogenerated-1-c4ca4238a0b923820dcc509a6f75849b\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\\/edit?site=autogenerated-1-c4ca4238a0b923820dcc509a6f75849b\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-_vtv_oTTeVmZ-HMa1vpisgRkHGX8VdeFm71sQKO1272XBrmVSHRtFg\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771673728031685&requestHash=849b6392d364355a765bf3c6ad4a8d6451e94103\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('9d66bf26-ac4e-4b32-9d17-4fa2d1b5c6b3',0,1771753734,1771753734,'csp-report','backend',1771753734764501,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/system\\/log\\/BackendLog\\/list\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/system\\/log\\/BackendLog\\/list\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-aiNidVEubqj3RSAsF82D6_9DdFq99YtX95gVtFeZXGtbD5yGoF6iEg\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771753734764501&requestHash=2160712db7c203acb27854143f5422e063807162\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('a37108cd-bcc2-42d7-9a02-12bee9aa0aeb',0,1771673626,1771673626,'csp-report','backend',1771673625950461,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/record\\/edit?edit%5Bpages%5D%5B1%5D=edit&overrideVals%5Bpages%5D%5Bsys_language_uid%5D=0&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D58fe10d32628300be336797b7de662bfb87eba15%26id%3D1\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-xBMNTvgAixWXsmrsttaKT0nTZOwipAKXDPaBI7yweuC5WE2GYDp9uA\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771673625950461&requestHash=f69eaf189a1f7ec993fb5ecf8d2a4ea493479b1f\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('a4b29d3b-c022-4080-9f65-74f46e4f7878',0,1771673618,1771673618,'csp-report','backend',1771673618764302,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/record\\/edit?edit%5Bpages%5D%5B1%5D=edit&overrideVals%5Bpages%5D%5Bsys_language_uid%5D=0&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D58fe10d32628300be336797b7de662bfb87eba15%26id%3D1\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/record\\/edit?edit%5Bpages%5D%5B1%5D=edit&overrideVals%5Bpages%5D%5Bsys_language_uid%5D=0&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D58fe10d32628300be336797b7de662bfb87eba15%26id%3D1\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-QYeXgxHTBl3PEaJl84ECsnwYBt3fUyk85NAQRKhmCEIYnVJCL1l9nA\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771673618764302&requestHash=8e32d91e739d0b098705d1481718f002afb6bd89\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('a606acb0-3491-4a9a-8b0b-c3d21721285e',0,1771680053,1771680053,'csp-report','backend',1771680053787904,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/web\\/layout?id=1\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/dashboard\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-ABbVyh0SjLZ2SjiHO84_Q06z3uMaIRQaZLZQ7kUYyKXVEer5Vur2Cw\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771680053787904&requestHash=454234b43aaaa1019c9f583a0a8f4c391a90def1\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('a9062f9d-94d8-4b5e-b74c-11fc48c6a98a',0,1771673703,1771673703,'csp-report','backend',1771673703508234,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/web\\/layout?id=1\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/web\\/layout?id=1\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-un_gyf3Lk9WYq0HWUOw9IwRbrSzXmaS5EwWYeeTY4afwa8pWB1Y4Gg\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771673703508234&requestHash=1faeae22d4d193596ff34aa49f5783d283cff513\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('aae16dec-7096-49ad-9455-7ae42c6ce75d',0,1771753515,1771753515,'csp-report','backend',1771753515504105,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\\/edit?site=gcanon\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\\/edit?site=gcanon\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-k0CbLzB9uBr52erhkK6YkseklOa2rXEpyEfps3MHOZ0zZucVE5cNTA\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771753515504105&requestHash=a7e00add86996f95bc09dfba0eef2b11b60f9155\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('ac47d946-e325-4b55-8c1a-2a64bad95a23',0,1771673596,1771673596,'csp-report','backend',1771673596549160,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/web\\/layout?id=1\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/record\\/edit?edit%5Bpages%5D%5B1%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D58fe10d32628300be336797b7de662bfb87eba15%26id%3D0\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-A-2W2d9VrjWk0F6iFYF4idznftdCRbkI0EroroXzkqN6ngsAamJl0g\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771673596549160&requestHash=16be4e2bc26245a029c80ce80285ae830befdd4d\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('b9c682da-25a3-45ac-ab73-2f6b5576075f',0,1771673689,1771673689,'csp-report','backend',1771673689113191,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\\/edit?site=autogenerated-1-c4ca4238a0b923820dcc509a6f75849b\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-cra_vc_LppwyvrFz5dYHxNKIKLVP3io_nc4ecDBHFkNtjeWeUeYWDA\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771673689113191&requestHash=54ad26536f28c50cea05f6de60bf8d11645c2e41\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('bb3a4e52-9869-4ceb-b0e0-501c7619c941',0,1771752835,1771752835,'csp-report','backend',1771752835103153,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/dashboard\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/main?redirect=dashboard\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-KNY-JiUs-apPBPUA8JCptIkRNtLzJdnlHZX3vhAO9yiuA3xJlIVXcA\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771752835103153&requestHash=0ac803c9f32720250dbb270ad55632edef1f7d98\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('be23b76e-d66f-4a5b-b47e-b68c0f7c0099',0,1771752610,1771752610,'csp-report','backend',1771752609548839,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/dashboard\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/main\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-MGLnmocxHpyiUd7BZw0nDHt_PHHhOGSGZTmDybpCvePfp7NgPmPY0g\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771752609548839&requestHash=c13698ba874f61ff47eb569efe63ddce45b662be\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('bf8b9fe1-b219-4b7d-9730-676531187462',0,1771673545,1771673545,'csp-report','backend',1771673544506284,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/web\\/layout?id=0\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/main?redirect=web_layout&redirectParams=id%3D0\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-SbHIbTmMMp2NenO3ZV7__09BxBA6dFfRQRovFGffw6e6cBVQgTGbMg\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771673544506284&requestHash=e6045fab160560dec6f34be467f2eb78d9dd0a15\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('c008878c-eea5-4889-a17e-ae4f5a5e81c9',0,1771674049,1771674049,'csp-report','backend',1771674049549239,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/tools\\/extensionmanager\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/sudo-mode\\/module?claim=b57bc3602f9322e7215e1966218e305e04062945&hash=eefb531d53d0ddb52b6b86ae350ce0414d8fe89b\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-MCbYhv19kTNhbwxZPybbVBHiRCK9FJ5iH_p8an_mdVT5tEI8BWo-8A\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771674049549239&requestHash=86cba97f870f22a9c1c549c7dd453c1e1cbe8bc5\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('c05f2aa5-8a85-47f7-bf2a-c5ac658321f4',0,1771673745,1771673745,'csp-report','backend',1771673745074364,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-0JGE_FeKVeqxQPXqzLMiAXtpZzKGSynBRntUExsWU4sfackI6E8vhA\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771673745074364&requestHash=c4595c209af3343a0939c2844260d7ee5d90eea2\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('cc0461da-eccf-4569-9dde-92f0fb476374',0,1771673390,1771673390,'csp-report','backend',1771673390058798,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/dashboard\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-sA_aXh5UXmUC8L7eknnxsq7eII2fO3LZkJgK0Lr9IM0Vv0KcX6kZvA\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771673390058798&requestHash=d207f9ce90e652b73924d3a7e9b64130e3c9ba2b\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('d074ec57-d651-4b5a-86a0-8089998cb12a',0,1771673698,1771673698,'csp-report','backend',1771673698541812,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/web\\/layout?id=1\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\\/edit?site=autogenerated-1-c4ca4238a0b923820dcc509a6f75849b\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-gSutylG3JsMnoxdEAPtEJxqxpcOtJf772Sn4fbTLIfCd_aEcaNfMDg\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771673698541812&requestHash=9e67b44792b56843c90c829a028609869a94a2d4\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('d878bfb3-10b1-4911-a091-5e2f2bc9f808',0,1771673296,1771673296,'csp-report','backend',1771673295307595,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/dashboard\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/main\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-_FjJOAjnFpwghUTKKrl3KFWbJb6rEX7Kut2cvbg3yYzEoAds4DiDoQ\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771673295307595&requestHash=b230b447ef0ca7c502a63d8c93fda171448b759a\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('dad8e0e9-3e6d-4262-b455-828edfd2ddd6',0,1771753490,1771753490,'csp-report','backend',1771753490549325,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/settings\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-iqNEAcF1zWgFqjiQkGD40wIbEyTQbxCfeyEMJCOVc0db4qMcP2DYjA\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771753490549325&requestHash=72eda977e4946f9427f96898131ad23495a4e64d\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('df425e55-251e-49ed-889b-20e0b8e29869',0,1771752949,1771752949,'csp-report','backend',1771752948983670,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/settings\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/settings\\/edit?site=gcanon\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-qscDmb5Nhsp7zM7bky4y7rTEhYWTYLHBBNEbOlzfEqvOyi0NLG55XA\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771752948983670&requestHash=67f64162b6b98c94a6c07cb6ec76f4197b449b04\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('e63f6a04-4e60-4ab1-8cb7-8981501ede2b',0,1771673947,1771673947,'csp-report','backend',1771673947116136,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\\/edit?site=gcanon\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\\/edit?site=gcanon\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-UkIXjgDS-F7to_INBiQtuPJKyZzp14sEFHHkGs2Rg9JYHhBCeUZMFg\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771673947116136&requestHash=43bc9d6393bb4ced2d9ba5ef04906678249896f1\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('e99536c8-285d-49ed-8a01-092ee8c2b67f',0,1771673656,1771673656,'csp-report','backend',1771673656123960,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\\/edit?site=autogenerated-1-c4ca4238a0b923820dcc509a6f75849b\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-2YogPnkTydg7mzisOims2sCfWE676OED-py3QduECehtG98foy5s7w\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771673656123960&requestHash=81b283d7f9187212e3176e247312b0cf21709890\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('eb6b669f-53d0-44c4-974e-fd4869d202aa',0,1771673654,1771673654,'csp-report','backend',1771673654353754,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\\/edit?site=autogenerated-1-c4ca4238a0b923820dcc509a6f75849b\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\\/edit?site=autogenerated-1-c4ca4238a0b923820dcc509a6f75849b\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-lEn-bY2L_JQpgQ4B9zqtEKAF8AOqUuL8KMK2QHTKXyYt4zafdRYZsg\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771673654353754&requestHash=bb3fba5979d53750a3fa847628e07f52eb6d42d8\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('f5522374-464f-4aef-9ab7-fbaad4a2210e',0,1771673644,1771673644,'csp-report','backend',1771673644130402,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\\/edit?site=autogenerated-1-c4ca4238a0b923820dcc509a6f75849b\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-63Gbo5P-mJALGQfcHgREGAjtm5-3AvIguCmORl2DfJV7e_k04zhNlw\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771673644130402&requestHash=19ba893954f4de49a7e0ac082deb13300a1b6399\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('f5b6aaad-9c77-4973-8aca-942836b8028e',0,1771674140,1771674140,'csp-report','backend',1771674140148564,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/web\\/layout?id=1\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/tools\\/extensionmanager\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-oHOVT3ZnjpIRrnVy_Agc0OjhBv11yhrIwoWc049UkNjpaE5XgVX1mg\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771674140148564&requestHash=391126f61f3c29314dbb4eb0a8339f4184ad2385\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('f8300015-092f-4d28-981b-92a43092a433',0,1771673716,1771673716,'csp-report','backend',1771673716113576,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\\/edit?site=autogenerated-1-c4ca4238a0b923820dcc509a6f75849b\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-U-CCscuTi_AejpdF4MVv2xqpL5MAOsAbkcQjaPkH6_iVWSfYIV2NPA\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771673716113576&requestHash=7e7020e41123784637c00ea7811c2d693ec5bbf4\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('f845105b-1d97-41c8-8f14-85760651ecbd',0,1771680028,1771680028,'csp-report','backend',1771680027391385,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/dashboard\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/main?redirect=dashboard&referrer-refresh=1771680031\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-G4y0WwZsg8az3Eqs4LtxYRAA2jdgjmzcDGU1ai3k1VL63lT4rNG7JA\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771680027391385&requestHash=e312db9549b357b18bd48fccffc5834ea7ee0944\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('fc361a0c-9b3e-4a30-a619-54453de30e23',0,1771673480,1771673480,'csp-report','backend',1771673480891654,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/web\\/layout?id=0\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-Amce-cPItVWrkzetUcs2SxBLHMjgWQ58KqwVfT_F2lT3DRPYnpYxTg\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771673480891654&requestHash=05f79c748c26ad31c84eec081aef5a5e9f0bc2ea\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969'),
('fe72454a-1a2e-48f7-9c74-2eca6c6e476b',0,1771752839,1771752839,'csp-report','backend',1771752839446277,'{\"addr\":\"172.21.0.0\",\"agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\\/edit?site=gcanon\",\"referrer\":\"https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/module\\/site\\/configuration\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce--RNX1kqktvtT1X0JIbPOCDLePBLkoTgnfdJZ78YkADNL0Z9JPP7Q_w\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/gcanon-typo3.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1771752839446277&requestHash=541e18d29a8c98b8006a6b3598dc6afb177879e1\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"column-number\":348,\"source-file\":\"chrome-extension\",\"status-code\":200,\"script-sample\":\";(function o(e,t=!1){const n=\\\"6.0\\\";let r\"}','99856c42462ff84fc22f8b1a8ea8e7584b56b969');
/*!40000 ALTER TABLE `sys_http_report` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--

LOCK TABLES `sys_lockedrecords` WRITE;
/*!40000 ALTER TABLE `sys_lockedrecords` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sys_lockedrecords` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_log` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `action` smallint(5) unsigned NOT NULL DEFAULT 0,
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `recpid` int(11) NOT NULL DEFAULT 0,
  `error` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details` text DEFAULT NULL,
  `type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `channel` varchar(20) NOT NULL DEFAULT 'default',
  `details_nr` smallint(6) NOT NULL DEFAULT 0,
  `IP` varchar(39) NOT NULL DEFAULT '',
  `log_data` text DEFAULT NULL,
  `event_pid` int(11) NOT NULL DEFAULT -1,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `request_id` varchar(13) NOT NULL DEFAULT '',
  `time_micro` double NOT NULL DEFAULT 0,
  `component` varchar(255) NOT NULL DEFAULT '',
  `level` varchar(10) NOT NULL DEFAULT 'info',
  `message` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`event_pid`),
  KEY `recuidIdx` (`recuid`),
  KEY `user_auth` (`type`,`action`,`tstamp`),
  KEY `request` (`request_id`),
  KEY `combined_1` (`tstamp`,`type`,`userid`),
  KEY `errorcount` (`tstamp`,`error`),
  KEY `index_channel` (`channel`),
  KEY `index_level` (`level`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_log`
--

LOCK TABLES `sys_log` WRITE;
/*!40000 ALTER TABLE `sys_log` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sys_log` VALUES
(1,1771673294,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.21.0.5','[\"gcanon\"]',-1,-99,'',0,'','info',NULL,NULL),
(2,1771673593,1,1,1,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.21.0.5','{\"table\":\"pages\",\"uid\":1,\"pid\":0}',0,0,'',0,'','info',NULL,NULL),
(3,1771673593,1,1,0,'site',0,0,'Site configuration \'%s\' was automatically created for new root page (%s).',6,'site',0,'172.21.0.5','[\"autogenerated-1-c4ca4238a0b923820dcc509a6f75849b\",1]',-1,0,'',0,'','info',NULL,NULL),
(4,1771673593,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.21.0.5','{\"table\":\"pages\",\"uid\":1,\"history\":\"2\"}',0,0,'',0,'','info',NULL,NULL),
(5,1771673618,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.21.0.5','{\"table\":\"pages\",\"uid\":1,\"history\":\"3\"}',0,0,'',0,'','info',NULL,NULL),
(6,1771673654,1,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site',0,'172.21.0.5','[\"autogenerated-1-c4ca4238a0b923820dcc509a6f75849b\"]',-1,0,'',0,'','info',NULL,NULL),
(7,1771673703,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.21.0.5','{\"table\":\"pages\",\"uid\":1,\"history\":\"4\"}',0,0,'',0,'','info',NULL,NULL),
(8,1771673728,1,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site',0,'172.21.0.5','[\"autogenerated-1-c4ca4238a0b923820dcc509a6f75849b\"]',-1,0,'',0,'','info',NULL,NULL),
(9,1771673792,1,3,0,'site',0,0,'Site configuration \'%s\' was renamed to \'%s\'.',6,'site',0,'172.21.0.5','[\"autogenerated-1-c4ca4238a0b923820dcc509a6f75849b\",\"gcanon\"]',-1,0,'',0,'','info',NULL,NULL),
(10,1771673792,1,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site',0,'172.21.0.5','[\"gcanon\"]',-1,0,'',0,'','info',NULL,NULL),
(13,1771673947,1,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site',0,'172.21.0.5','[\"gcanon\"]',-1,0,'',0,'','info',NULL,NULL),
(14,1771674293,1,2,0,'',0,0,'User %s logged out from TYPO3 Backend',255,'user',0,'172.21.0.5','[\"gcanon\"]',-1,0,'',0,'','info',NULL,NULL),
(15,1771676973,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.21.0.5','[\"gcanon\"]',-1,-99,'',0,'','info',NULL,NULL),
(18,1771752608,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.21.0.5','[\"gcanon\"]',-1,-99,'',0,'','info',NULL,NULL),
(21,1771753515,1,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site',0,'172.21.0.5','[\"gcanon\"]',-1,0,'',0,'','info',NULL,NULL),
(23,1771753678,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.21.0.5','{\"username\":\"gcanon\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(24,1771753718,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.21.0.5','{\"username\":\"gcanon\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL);
/*!40000 ALTER TABLE `sys_log` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `sys_messenger_messages`
--

DROP TABLE IF EXISTS `sys_messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_messenger_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL,
  `available_at` datetime NOT NULL,
  `delivered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `queue_name` (`queue_name`),
  KEY `available_at` (`available_at`),
  KEY `delivered_at` (`delivered_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_messenger_messages`
--

LOCK TABLES `sys_messenger_messages` WRITE;
/*!40000 ALTER TABLE `sys_messenger_messages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sys_messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `sys_note`
--

DROP TABLE IF EXISTS `sys_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_note` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `cruser` int(10) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  `subject` varchar(255) NOT NULL DEFAULT '',
  `message` longtext DEFAULT NULL,
  `personal` smallint(5) unsigned NOT NULL DEFAULT 0,
  `position` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_note`
--

LOCK TABLES `sys_note` WRITE;
/*!40000 ALTER TABLE `sys_note` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sys_note` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `sys_reaction`
--

DROP TABLE IF EXISTS `sys_reaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_reaction` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `impersonate_user` int(10) unsigned NOT NULL DEFAULT 0,
  `storage_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `reaction_type` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT '',
  `identifier` varchar(36) NOT NULL DEFAULT '',
  `secret` varchar(255) NOT NULL DEFAULT '',
  `table_name` varchar(255) NOT NULL DEFAULT '',
  `fields` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`fields`)),
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`reaction_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_reaction`
--

LOCK TABLES `sys_reaction` WRITE;
/*!40000 ALTER TABLE `sys_reaction` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sys_reaction` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `tablename` varchar(64) NOT NULL DEFAULT '',
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `field` varchar(64) NOT NULL DEFAULT '',
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `flexpointer` varchar(255) NOT NULL DEFAULT '',
  `softref_key` varchar(30) NOT NULL DEFAULT '',
  `softref_id` varchar(40) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `workspace` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_table` varchar(64) NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_field` varchar(64) NOT NULL DEFAULT '',
  `ref_hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `ref_starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `ref_t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_sorting` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`,`recuid`,`field`,`workspace`,`ref_t3ver_state`,`ref_hidden`,`ref_starttime`,`ref_endtime`),
  KEY `lookup_ref` (`ref_table`,`ref_uid`,`tablename`,`workspace`,`t3ver_state`,`hidden`,`starttime`,`endtime`),
  KEY `lookup_string` (`ref_string`(191)),
  KEY `idx_softref_key` (`softref_key`,`ref_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) NOT NULL DEFAULT '',
  `entry_key` varchar(128) NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sys_registry` VALUES
(1,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendGroupsExplicitAllowDenyMigration','i:1;'),
(2,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendModulePermissionMigration','i:1;'),
(3,'installUpdate','TYPO3\\CMS\\Install\\Updates\\IndexedSearchCTypeMigration','i:1;'),
(4,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigrateSiteSettingsConfigUpdate','i:1;'),
(5,'installUpdate','TYPO3\\CMS\\Install\\Updates\\PagesRecyclerDoktypeMigration','i:1;'),
(6,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SynchronizeColPosAndCTypeWithDefaultLanguage','i:1;'),
(7,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysFileCollectionIdentifierMigration','i:1;'),
(8,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysFileMountIdentifierMigration','i:1;'),
(9,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysLogSerializationUpdate','i:1;'),
(10,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysTemplateNoWorkspaceMigration','i:1;'),
(11,'installUpdate','TYPO3\\CMS\\Extensionmanager\\Updates\\FeLoginModeExtractionUpdate','i:1;'),
(12,'installUpdateRows','rowUpdatersDone','a:1:{i:0;s:69:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\SysRedirectRootPageMoveMigration\";}'),
(14,'core','formProtectionSessionToken:1','s:64:\"70303c878e03942ee30bd0bb24fb700ddd4e3748f2c1ea2dc306504e31d47087\";');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `constants` longtext DEFAULT NULL,
  `include_static_file` longtext DEFAULT NULL,
  `basedOn` longtext DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `config` longtext DEFAULT NULL,
  `static_file_mode` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `sys_webhook`
--

DROP TABLE IF EXISTS `sys_webhook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_webhook` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `webhook_type` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT '',
  `identifier` varchar(36) NOT NULL DEFAULT '',
  `secret` varchar(255) NOT NULL DEFAULT '',
  `url` text NOT NULL DEFAULT '',
  `method` varchar(10) NOT NULL DEFAULT '',
  `verify_ssl` smallint(5) unsigned NOT NULL DEFAULT 1,
  `additional_headers` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`additional_headers`)),
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`webhook_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_webhook`
--

LOCK TABLES `sys_webhook` WRITE;
/*!40000 ALTER TABLE `sys_webhook` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sys_webhook` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `frame_class` varchar(60) NOT NULL DEFAULT 'default',
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `table_caption` varchar(255) DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `CType` varchar(255) NOT NULL DEFAULT '',
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) NOT NULL DEFAULT '',
  `space_after_class` varchar(60) NOT NULL DEFAULT '',
  `date` bigint(20) NOT NULL DEFAULT 0,
  `header` varchar(255) NOT NULL DEFAULT '',
  `header_layout` int(10) unsigned NOT NULL DEFAULT 0,
  `header_position` varchar(255) NOT NULL DEFAULT '',
  `header_link` text NOT NULL DEFAULT '',
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `bodytext` longtext DEFAULT NULL,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned NOT NULL DEFAULT 0,
  `imageheight` int(10) unsigned NOT NULL DEFAULT 0,
  `imageorient` int(10) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imagecols` int(10) unsigned NOT NULL DEFAULT 0,
  `pages` longtext DEFAULT NULL,
  `recursive` int(10) unsigned NOT NULL DEFAULT 0,
  `list_type` varchar(255) NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `records` longtext DEFAULT NULL,
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 1,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` longtext DEFAULT NULL,
  `selected_categories` longtext DEFAULT NULL,
  `category_field` varchar(64) NOT NULL DEFAULT '',
  `bullets_type` int(10) unsigned NOT NULL DEFAULT 0,
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `table_class` varchar(60) NOT NULL DEFAULT '',
  `table_delimiter` int(10) unsigned NOT NULL DEFAULT 0,
  `table_enclosure` int(10) unsigned NOT NULL DEFAULT 0,
  `table_header_position` int(10) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` longtext DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(64) NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) NOT NULL DEFAULT '',
  `target` varchar(30) NOT NULL DEFAULT '',
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l18n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tx_extensionmanager_domain_model_extension`
--

DROP TABLE IF EXISTS `tx_extensionmanager_domain_model_extension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_extensionmanager_domain_model_extension` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `extension_key` varchar(60) NOT NULL DEFAULT '',
  `remote` varchar(100) NOT NULL DEFAULT 'ter',
  `version` varchar(15) NOT NULL DEFAULT '',
  `alldownloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `downloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(150) NOT NULL DEFAULT '',
  `serialized_dependencies` mediumtext DEFAULT NULL,
  `author_name` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `ownerusername` varchar(50) NOT NULL DEFAULT '',
  `md5hash` varchar(35) NOT NULL DEFAULT '',
  `authorcompany` varchar(255) NOT NULL DEFAULT '',
  `integer_version` int(11) NOT NULL DEFAULT 0,
  `lastreviewedversion` int(11) NOT NULL DEFAULT 0,
  `documentation_link` varchar(2048) DEFAULT NULL,
  `distribution_image` varchar(255) DEFAULT NULL,
  `distribution_welcome_image` varchar(255) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `state` int(10) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  `last_updated` bigint(20) NOT NULL DEFAULT 0,
  `update_comment` longtext DEFAULT NULL,
  `current_version` smallint(5) unsigned NOT NULL DEFAULT 0,
  `review_state` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `versionextrepo` (`extension_key`,`version`,`remote`),
  KEY `index_extrepo` (`extension_key`,`remote`),
  KEY `index_versionrepo` (`integer_version`,`remote`,`extension_key`),
  KEY `index_currentversions` (`current_version`,`review_state`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_extensionmanager_domain_model_extension`
--

LOCK TABLES `tx_extensionmanager_domain_model_extension` WRITE;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tx_impexp_presets`
--

DROP TABLE IF EXISTS `tx_impexp_presets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_impexp_presets` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `public` smallint(6) NOT NULL DEFAULT 0,
  `item_uid` int(11) NOT NULL DEFAULT 0,
  `user_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `preset_data` blob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `lookup` (`item_uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_impexp_presets`
--

LOCK TABLES `tx_impexp_presets` WRITE;
/*!40000 ALTER TABLE `tx_impexp_presets` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tx_impexp_presets` ENABLE KEYS */;
UNLOCK TABLES;
commit;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-02-22 14:04:18
